<?php
/**
 * Deco Nice - Conexión de Base de Datos Segura (PDO + Prepared Statements)
 * Credenciales cargadas desde variables de entorno (.env fuera del web root)
 */

$envPath = __DIR__ . '/../../.env';
if (file_exists($envPath)) {
    $env = parse_ini_file($envPath);
} else {
    $env = [
        'DB_HOST' => getenv('DB_HOST') ?: 'localhost',
        'DB_NAME' => getenv('DB_NAME') ?: 'deconice_db',
        'DB_USER' => getenv('DB_USER') ?: 'deconice_user',
        'DB_PASS' => getenv('DB_PASS') ?: '',
        'DB_CHARSET' => getenv('DB_CHARSET') ?: 'utf8mb4',
    ];
}

$db_config = [
    'host'     => $env['DB_HOST'],
    'dbname'   => $env['DB_NAME'],
    'user'     => $env['DB_USER'],
    'pass'     => $env['DB_PASS'],
    'charset'  => $env['DB_CHARSET'],
];

if (empty($db_config['pass'])) {
    error_log("CRÍTICO: DB_PASS no configurado en variables de entorno");
}

try {
    $dsn = "mysql:host={$db_config['host']};dbname={$db_config['dbname']};charset={$db_config['charset']}";
    $pdo = new PDO($dsn, $db_config['user'], $db_config['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    error_log("Error de conexión BD: " . $e->getMessage());
    $pdo = null;
}
