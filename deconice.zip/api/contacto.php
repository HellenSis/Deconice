<?php
/**
 * Deco Nice - Procesador Seguro de Formulario de Contacto / Citas
 * Envía correo a contacto@deconiceperu.com y guarda en BD
 */

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/db.php';

set_security_headers();
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// ── Rate Limiting (5 req/min por IP) ──────────────────────────────────────────
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateFile = sys_get_temp_dir() . "/ratelimit_contact_$ip";
$now = time();
$requests = file_exists($rateFile) ? json_decode(file_get_contents($rateFile), true) : [];
$requests = array_filter($requests, fn($t) => $now - $t < 60);
if (count($requests) >= 5) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Demasiadas solicitudes. Intente en 1 minuto.']);
    exit;
}
$requests[] = $now;
file_put_contents($rateFile, json_encode($requests));

// ── Honeypot (campo oculto "website") ─────────────────────────────────────────
if (!empty($_POST['website'] ?? '')) {
    echo json_encode(['success' => true, 'message' => 'Mensaje enviado']);
    exit;
}

// ── CSRF Token ────────────────────────────────────────────────────────────────
if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Token de seguridad inválido']);
    exit;
}

// ── Sanitización ──────────────────────────────────────────────────────────────
$nombre  = clean_input($_POST['nombre']  ?? '');
$celular = clean_input($_POST['celular'] ?? '');
$email   = clean_input($_POST['email']   ?? '');
$fecha   = clean_input($_POST['fecha']   ?? '');
$hora    = clean_input($_POST['hora']    ?? '');
$mensaje = clean_input($_POST['mensaje'] ?? '');

// ── Validación Estricta Server-Side ───────────────────────────────────────────
$errors = [];

// Nombre: 2-100 chars
if (!preg_match('/^[\p{L}\s\'\-]{2,100}$/u', $nombre)) {
    $errors[] = 'Nombre inválido (2-100 caracteres, solo letras)';
}

// Teléfono Perú
$celularClean = preg_replace('/\D/', '', $celular);
if (!preg_match('/^(?:51)?9\d{8}$/', $celularClean)) {
    $errors[] = 'Teléfono inválido (formato Perú: 9XXXXXXXXX)';
}

// Email opcional
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Email inválido';
}

// Fecha: no pasada (opcional)
if ($fecha !== '') {
    $today = date('Y-m-d');
    if ($fecha < $today) {
        $errors[] = 'Fecha no puede ser anterior a hoy';
    }
}

// Mensaje: máx 2000 chars
if (mb_strlen($mensaje) > 2000) {
    $errors[] = 'Mensaje muy largo (máx 2000 caracteres)';
}

if ($errors) {
    echo json_encode(['success' => false, 'message' => implode('. ', $errors)]);
    exit;
}

// ── 1. Enviar correo de notificación ──────────────────────────────────────────
$destinatario = 'contacto@deconiceperu.com';
$asunto       = '=?UTF-8?B?' . base64_encode("📞 Nuevo Contacto / Cita - $nombre") . '?=';
$fechaHora    = ($fecha ?: 'No especificada') . ($hora ? " a las $hora" : '');

$cuerpo = "NUEVO MENSAJE DE CONTACTO / SOLICITUD DE CITA - DECO NICE\n";
$cuerpo .= str_repeat("=", 55) . "\n\n";
$cuerpo .= "Nombre:          $nombre\n";
$cuerpo .= "Teléfono:        $celular\n";
$cuerpo .= "Email:           " . ($email ?: 'No especificado') . "\n";
$cuerpo .= "Fecha Preferida: $fechaHora\n";
$cuerpo .= "Mensaje:         " . ($mensaje ?: 'Sin mensaje adicional') . "\n\n";
$cuerpo .= str_repeat("=", 55) . "\n";
$cuerpo .= "IP Origen: " . $ip . "\n";
$cuerpo .= "Fecha:     " . date('d/m/Y H:i:s') . "\n";
$cuerpo .= "Fuente:    deconiceperu.com/contacto.html\n";

$headers  = "From: no-reply@deconiceperu.com\r\n";
$safeEmail = filter_var($email, FILTER_VALIDATE_EMAIL);
$safeEmail = $safeEmail ? str_replace(["\r", "\n"], '', $safeEmail) : $destinatario;
$headers .= "Reply-To: $safeEmail\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "Content-Transfer-Encoding: base64\r\n";

$correoEnviado = mail($destinatario, $asunto, base64_encode($cuerpo), $headers);

if (!$correoEnviado) {
    error_log("⚠️ No se pudo enviar correo de contacto para: $nombre ($celular)");
}

// ── 2. Guardar en Base de Datos ───────────────────────────────────────────────
if ($pdo) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO cotizaciones (producto_categoria, medidas, departamento, distrito, nombre, celular, email, ip_origen)
             VALUES ('Contacto / Cita', ?, 'Lima', 'Independencia', ?, ?, ?, ?)"
        );
        $stmt->execute([$mensaje, $nombre, $celular, $email, $ip]);
    } catch (PDOException $e) {
        error_log("Error guardando contacto: " . $e->getMessage());
    }
}

// ── 3. Respuesta al cliente ───────────────────────────────────────────────────
echo json_encode([
    'success' => true,
    'message' => "¡Gracias $nombre! Hemos recibido tu mensaje. Nos contactaremos al $celular a la brevedad."
]);