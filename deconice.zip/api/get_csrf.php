<?php
/**
 * Deco Nice - Endpoint para obtener token CSRF
 */
require_once __DIR__ . '/security.php';

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['token' => generate_csrf_token()]);