<?php
/**
 * Deco Nice - Módulo de Seguridad PHP (CSRF, Sanitización, Rate Limit, Honeypot & Headers)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_secure'   => isset($_SERVER['HTTPS']),
        'cookie_samesite' => 'Strict'
    ]);
}

/**
 * Genera un token CSRF criptográficamente seguro
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verifica un token CSRF
 */
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Desinfecta y limpia entradas de texto para evitar XSS
 */
function clean_input($data) {
    if (is_array($data)) {
        return array_map('clean_input', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Rate limiting simple basado en archivos (por IP + acción)
 * @param string $action Acción a limitar (ej: 'contact_form', 'quote_form')
 * @param int $maxRequests Máximo requests permitidos
 * @param int $windowSeconds Ventana de tiempo en segundos
 * @return bool true si permitido, false si excedido
 */
function check_rate_limit($action, $maxRequests = 5, $windowSeconds = 60) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $key = "ratelimit_{$action}_{$ip}";
    $file = sys_get_temp_dir() . "/{$key}.json";
    
    $now = time();
    $data = [];
    
    if (file_exists($file)) {
        $content = @file_get_contents($file);
        if ($content) {
            $data = json_decode($content, true) ?: [];
        }
    }
    
    // Filtrar requests fuera de la ventana
    $data = array_filter($data, fn($ts) => $now - $ts < $windowSeconds);
    
    if (count($data) >= $maxRequests) {
        return false;
    }
    
    $data[] = $now;
    @file_put_contents($file, json_encode($data), LOCK_EX);
    return true;
}

/**
 * Valida campo honeypot (debe estar vacío)
 * @param string $fieldName Nombre del campo honeypot (default: 'website')
 * @return bool true si pasa (vacío), false si bot detectado
 */
function check_honeypot($fieldName = 'website') {
    $value = $_POST[$fieldName] ?? '';
    return empty($value);
}

/**
 * Valida email y sanitiza para headers (previene header injection)
 * @return string Email seguro o fallback
 */
function sanitize_email_for_header($email, $fallback) {
    $safe = filter_var($email, FILTER_VALIDATE_EMAIL);
    return $safe ? str_replace(["\r", "\n"], '', $safe) : $fallback;
}

/**
 * Valida teléfono formato Perú (+51 9XXXXXXXX)
 */
function validate_phone_pe($phone) {
    $clean = preg_replace('/\D/', '', $phone);
    return preg_match('/^519\d{8}$/', $clean);
}

/**
 * Envía encabezados de seguridad en respuestas PHP
 */
function set_security_headers() {
    header("X-Frame-Options: DENY");
    header("X-Content-Type-Options: nosniff");
    header("Referrer-Policy: strict-origin-when-cross-origin");
    header("X-XSS-Protection: 1; mode=block");
}
