/**
 * Deco Nice Boutique - Script Principal
 * Funcionalidades globales para navegaci�n responsive, modales, toasts e interacci�n.
 */

document.addEventListener('DOMContentLoaded', () => {
    initMobileMenu();
    initActiveNav();
    initWhatsAppButton();
});

/**
 * Inicializa el men� hamburguesa m�vil en todas las p�ginas
 */
function initMobileMenu() {
    const menuButtons = document.querySelectorAll('header button.md\\:hidden, nav button.md\\:hidden');
    if (menuButtons.length === 0) return;

    let mobileDrawer = document.getElementById('mobile-nav-drawer');
    if (!mobileDrawer) {
        mobileDrawer = document.createElement('div');
        mobileDrawer.id = 'mobile-nav-drawer';
        mobileDrawer.className = 'fixed inset-0 z-[100] bg-on-surface/50 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 md:hidden';

        mobileDrawer.innerHTML = `
            <div class="fixed top-0 right-0 w-4/5 max-w-xs h-full bg-surface shadow-2xl p-6 flex flex-col justify-between transform translate-x-full transition-transform duration-300 ease-out" id="mobile-nav-panel">
                <div>
                    <div class="flex justify-between items-center pb-6 border-b border-outline-variant/30">
                        <div class="flex items-center gap-3">
                            <img src="image/logodeconice.png" alt="Deco Nice" class="h-10 w-auto object-contain">
                            <span class="font-headline text-headline-sm text-primary font-bold">Deco Nice</span>
                        </div>
                        <button id="close-mobile-nav" class="p-2 text-on-surface hover:text-primary transition-colors">
                            <span class="material-symbols-outlined">close</span>
                        </button>
                    </div>
                    <nav class="flex flex-col gap-4 py-6 font-nav-item text-nav-item uppercase tracking-widest">
                        <a href="index.html" class="py-2 border-b border-outline-variant/10 text-secondary hover:text-primary transition-colors">Inicio</a>
                        <a href="catalogo.html" class="py-2 border-b border-outline-variant/10 text-secondary hover:text-primary transition-colors">Cat�logo</a>
                        <a href="galeria_proyectos.html" class="py-2 border-b border-outline-variant/10 text-secondary hover:text-primary transition-colors">Proyectos</a>
                        <a href="cobertura.html" class="py-2 border-b border-outline-variant/10 text-secondary hover:text-primary transition-colors">Cobertura</a>
                        <a href="contacto.html" class="py-2 border-b border-outline-variant/10 text-secondary hover:text-primary transition-colors">Contacto</a>
                    </nav>
                </div>
                <div class="pt-6 border-t border-outline-variant/30 flex flex-col gap-3">
                    <a href="cotizar.html" class="w-full text-center py-3 bg-primary text-on-primary font-label-caps uppercase rounded-xl shadow-md hover:bg-primary-container transition-all">
                        Solicitar Cotizaci�n
                    </a>
                    <a href="https://wa.me/51997963268?text=Hola%20Deco%20Nice,%20deseo%20mayor%20informaci%C3%B3n." target="_blank" class="w-full text-center py-3 border border-primary text-primary font-label-caps uppercase rounded-xl hover:bg-primary/5 transition-all flex items-center justify-center gap-2">
                        <span class="material-symbols-outlined text-lg">chat</span> WhatsApp
                    </a>
                </div>
            </div>
        `;
        document.body.appendChild(mobileDrawer);
    }

    const panel = document.getElementById('mobile-nav-panel');
    const closeBtn = document.getElementById('close-mobile-nav');

    function openMenu() {
        mobileDrawer.classList.remove('opacity-0', 'pointer-events-none');
        mobileDrawer.classList.add('opacity-100', 'pointer-events-auto');
        panel.classList.remove('translate-x-full');
        panel.classList.add('translate-x-0');
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        mobileDrawer.classList.remove('opacity-100', 'pointer-events-auto');
        mobileDrawer.classList.add('opacity-0', 'pointer-events-none');
        panel.classList.remove('translate-x-0');
        panel.classList.add('translate-x-full');
        document.body.style.overflow = '';
    }

    menuButtons.forEach(btn => btn.addEventListener('click', openMenu));
    if (closeBtn) closeBtn.addEventListener('click', closeMenu);
    mobileDrawer.addEventListener('click', (e) => {
        if (e.target === mobileDrawer) closeMenu();
    });
}

/**
 * Resalta la pesta�a correspondiente en la barra de navegaci�n seg�n la p�gina actual
 */
function initActiveNav() {
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('header nav a, #mobile-nav-drawer nav a');

    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (!href) return;

        if (href === currentPath || (currentPath === '' && href === 'index.html') || (currentPath === 'inicio.html' && href === 'index.html')) {
            link.classList.add('text-primary', 'font-bold');
            if (link.parentElement.tagName === 'NAV' && !link.classList.contains('border-b')) {
                link.classList.add('border-b', 'border-primary', 'pb-1');
            }
        }
    });
}

/**
 * Agrega el bot�n flotante de WhatsApp (color vino, rectangular) a todas las p�ginas
 */
function initWhatsAppButton() {
    if (document.getElementById('whatsapp-floating-btn')) return;

    const waBtn = document.createElement('a');
    waBtn.id = 'whatsapp-floating-btn';
    waBtn.href = 'https://wa.me/51997963268?text=Hola%20Deco%20Nice,%20deseo%20consultar%20sobre%20sus%20servicios.';
    waBtn.target = '_blank';
    waBtn.rel = 'noopener noreferrer';
    waBtn.ariaLabel = 'Contactar por WhatsApp';
    waBtn.className = 'fixed bottom-8 right-8 z-50 bg-tertiary text-on-tertiary rounded-xl px-6 py-4 shadow-2xl hover:bg-terracotta-hover hover:scale-110 transition-all duration-300 flex items-center gap-2 font-label-caps text-label-caps uppercase tracking-widest';
    waBtn.innerHTML = `
        <span class="material-symbols-outlined">chat</span>
        <span>WhatsApp</span>
    `;
    document.body.appendChild(waBtn);
}

/**
 * Utilidad de notificaci�n flotante (Toast)
 */
function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'fixed bottom-20 right-6 z-[120] flex flex-col gap-2 max-w-md';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const isError = type === 'error';
    toast.className = `p-4 rounded-xl shadow-xl backdrop-blur-md text-sm font-body flex items-center gap-3 transition-all duration-300 transform translate-y-4 opacity-0 ${isError ? 'bg-error text-on-error' : 'bg-primary text-on-primary'
        }`;

    toast.innerHTML = `
        <span class="material-symbols-outlined text-xl">${isError ? 'error' : 'check_circle'}</span>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    requestAnimationFrame(() => {
        toast.classList.remove('translate-y-4', 'opacity-0');
        toast.classList.add('translate-y-0', 'opacity-100');
    });

    setTimeout(() => {
        toast.classList.remove('translate-y-0', 'opacity-100');
        toast.classList.add('translate-y-4', 'opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}